
# =============================================================================
#                   IMPORTING CONCERNED LIBRARIES
# =============================================================================

import os
import time
import math
import urllib
import timeit
import numpy as np
import pandas as pd
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.support.ui import WebDriverWait
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.support import expected_conditions as EC


if __name__ == '__main__':
    
# =============================================================================
#               GETTING THE CURRENT WORKING DIRECTORY
# =============================================================================
    
    path = os.getcwd()
    
# =============================================================================
#     SETTING CHROME OPTIONS TO DEAL WITH CHROME NOT OPENING ERROR
# =============================================================================

    chrome_options = webdriver.ChromeOptions()
    chrome_options.add_argument('--no-sandbox')
    chrome_options.add_argument('--window-size=1420,1080')
    #chrome_options.add_argument('--headless')
    chrome_options.add_argument('--disable-gpu')
    driver = webdriver.Chrome(chrome_options=chrome_options)

# =============================================================================
#   wait and small_wait ARE DELAYS/SLEEP TIMES TO BE ADDED IN BETWEEN
# =============================================================================
    
#    wait = WebDriverWait(driver,10)
#    small_wait = WebDriverWait(driver,4)
    
# =============================================================================
#    SPECIFYING LOCATIONS IN array AND CATEGORY IN category variable
# =============================================================================
   
    all_data = pd.DataFrame()
    #array = ['Mumbai','Thane','Kalyan','Vasai','Hyderabad','Patna','Ranchi']
    ar = 'Chandigarh'
    category = "childrens+store"

# =============================================================================
#                  ACCESSING URL & HTML OF THAT PAGE
# =============================================================================

    for ar in array:
        URL = "https://www.google.com/maps/search/" + category + "+in+" + ar + "/" 
        driver.get(URL)
        html_source = driver.page_source
        soup = BeautifulSoup(html_source, 'html.parser')
        pages = 0
        start = timeit.default_timer()
        time.sleep(10)

# =============================================================================
#                CHECKING THAT THERE ARE MORE STORES LEFT
# =============================================================================

        while(driver.find_elements_by_xpath("//div[@class = \'section-result\']") != [] and pages < 15):
            
            div_count = len(driver.find_elements_by_xpath("//div[@class = \'section-result\']"))
            #div_count = len(soup.find_all('div',{'class':'section-result'}))
            for count in range(div_count):
                    time.sleep(7)
                    driver.find_elements_by_xpath("//div[@class = \'section-result\']")[count].click()
                    time.sleep(7)
                    
# =============================================================================
#                       STORING NAME OF THE STORE
# =============================================================================
                    
                    name = driver.find_elements_by_xpath("//h1[@class = \'section-hero-header-title-title GLOBAL__gm2-headline-5\']/span")
                    if (name != []):
                        data = pd.DataFrame([name[0].text.strip()], columns = ['Name'])
                    else:
                        print('Name not found')
                        driver.find_elements_by_xpath("//button[@class = \'section-back-to-list-button blue-link noprint\']")[0].click()
                        #driver.execute_script("window.document.getElementsByClassName('section-back-to-list-button blue-link noprint')[0].click();")
                        time.sleep(3)
                        #continue
                        
# =============================================================================
#                         STORING RATING OF THE STORE
# =============================================================================
                    rating = driver.find_elements_by_xpath("//span[@class = \'section-star-display\']")
                    #rating = soup.find('span',{'class' : 'section-star-display'})
                    if(rating != []):
                        data['Rating'] = pd.DataFrame([rating[0].text.strip()])
                        #data['Num_review'] = pd.DataFrame([soup.find('span',{'class' : 'section-rating-term-list'}).text])
                    else:
                        data['Rating'] = pd.DataFrame([''])
                    
# =============================================================================
#                       STORING NO. OF REVIEWS THE STORE
# =============================================================================                    
                    num_review = driver.find_elements_by_xpath("//button[@jsaction = \'pane.rating.moreReviews\']")
                    if(num_review != []):
                        data['Num_review'] = pd.DataFrame([num_review[0].text.strip()])
                    else:
                        data['Num_review'] = pd.DataFrame([''])
              
# =============================================================================
#                        STORING CATEGORY OF THE STORE
# =============================================================================                    
                   
                    categ = driver.find_elements_by_xpath("//button[@jsaction = \'pane.rating.category\']")
                    if(categ != []):
                        data['Category'] = pd.DataFrame([categ[0].text.strip()])
                    else:
                        data['Category'] = pd.DataFrame([''])
                    #data['Category'] = pd.DataFrame([soup.find_all('div',{'class':'GLOBAL__gm2-body-2'})[1].text])

# =============================================================================
#                      STORING ADDRESS OF THE STORE
# =============================================================================
                    add = driver.find_elements_by_xpath("//button[contains(@data-item-id,'address')]/div/div/div")
                    #add = soup.find('div',{'class' : 'section-info-action-button'})
                    if(add != []):
                        data['Address'] = pd.DataFrame([add[1].text.strip()])
                    else:
                        data['Address'] = pd.DataFrame([''])

# =============================================================================
#                     STORING PHONE NO. OF THE STORE
# =============================================================================
                    phone = driver.find_elements_by_xpath("//button[contains(@data-item-id,'phone')]/div/div/div")
                    if(phone != []):
                        phone = phone[1]
                        #phone = soup.find('div',{'class':'section-info-action-button section-info-speak-numeral'})
                        data['Contact'] = pd.DataFrame([phone.text.strip()])
                    else:
                        data['Contact'] = pd.DataFrame([''])

# =============================================================================
#     APPENDING data(1 STORE DATA) TO all_data(DUMP OF ALL STORES)
# =============================================================================
                    
                    all_data = all_data.append(data, ignore_index = True)
                    #time.sleep(5)
                    driver.find_elements_by_xpath("//button[@class = \'section-back-to-list-button blue-link noprint\']")[0].click()
                    #driver.execute_script("window.document.getElementsByClassName('section-back-to-list-button blue-link noprint')[0].click();")#,WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.CLASS_NAME, "div.section-back-to-list-button blue-link noprint")))
                    #time.sleep(5)
                
# =============================================================================
#                    GO TO THE NEXT PAGE OF RESULTS
# =============================================================================
            
            print("Page " + str(pages) + " Done")
            time.sleep(7)
            if(driver.find_elements_by_xpath("//button[@id = \'n7lv7yjyC35__section-pagination-button-next\' and @class = \'n7lv7yjyC35__button noprint n7lv7yjyC35__button-disabled\']")):
                break
            driver.find_elements_by_xpath("//button[@id = \'n7lv7yjyC35__section-pagination-button-next\']")[0].click()            
            #driver.execute_script("window.document.getElementById('n7lv7yjyC35__section-pagination-button-next').click();")
            time.sleep(10)
            pages = pages + 1
            
        stop = timeit.default_timer()   
        print('Run time = ' + str(stop - start) + 'seconds')

# =============================================================================
#               DELETING DUPLICATES & ADDING PLACE NAME
# =============================================================================
        
        all_data = all_data.drop_duplicates()    
        all_data['Place'] = ar    
        all_data = all_data.reset_index().drop(columns = ['index'])
        driver.quit()

# =============================================================================
#         CHANGE NAME OF PICKLE FILE BEFORE STORING NEW DATA IF NEEDED
# =============================================================================


        temp = pd.read_pickle(path + '/Pickle Files/chandigarh.pickle')
        temp = temp.append(all_data, ignore_index = True)
        temp.to_pickle(path + '/Pickle Files/chandigarh.pickle')
        
        
# =============================================================================
#                    CODE TO SEPARATE PINCODES
# =============================================================================

    data = pd.read_excel(path + '/Output/Chandigarh.xlsx')
    data['Pincode'] = np.nan
    state = ['Chandigarh']
    for st in state:
        for i in range(len(data)) :
            if(pd.isna(data.Address[i])):
                continue
            t = data.Address[i].split(st)
            if (len(t) > 1):
                data['Pincode'][i] = data.Address[i].split(st)[1]
    
    data['Pincode'] = data['Pincode'].astype(str)
    data = data.dropna(axis = 0, subset = ['Pincode'])
    for i in range(len(data)):
        data['Pincode'][i] = data['Pincode'][i].lstrip()
        data['Pincode'][i] = data['Pincode'][i].split(' ')[0]
    
    data['Pincode'] = data['Pincode'].astype(float)
    data['Pincode'] = data['Pincode'].astype(int)
    
    data.to_excel(path + '/Output/PincodesDump.xlsx')
    
    
        
        

    